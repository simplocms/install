<?php

return [
    'name' => 'Text',
    'icon' => 'font'
];
