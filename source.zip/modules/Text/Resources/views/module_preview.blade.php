<div style="max-height:600px;white-space: nowrap;overflow: hidden;text-overflow: ellipsis;">
    {!! $configuration->content !!}
</div>
