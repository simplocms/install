<?php

return [

    'grid_editor_form' => [
        'label_content' => 'Content',
    ],

    'preview_title' => 'Text module',

    'validation_messages' => [
        'content.required' => 'Please enter the content.'
    ]

];
