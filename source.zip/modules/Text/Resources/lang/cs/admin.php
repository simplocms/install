<?php

return [

    'grid_editor_form' => [
        'label_content' => 'Obsah',
    ],

    'preview_title' => 'Modul text',

    'validation_messages' => [
        'content.required' => 'Zadejte prosím obsah modulu.'
    ]

];
