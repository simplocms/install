## CMS MODULE - VIEW

### Použití

- [Návod na wiki](https://bitbucket.org/simplo-cz/simplo-cms/wiki/Modul%20View)

### Build skriptu

Pokud je potřeba upravit skript modulu, je potřeba nainstalovat npm knihovny příkazem `npm i`.

Modul používá knihovnu `laravel-mix`, takže je možné používat pro něj typické příkazy pro build.

**Před commitem do repozitáře je potřeba provést build pro produkci příkazem `npm run prod`!**
