<?php

return [
    'name' => 'View',
    'icon' => 'file-text-o',

    'grideditor_title' => 'module-view::admin.grideditor_title'
];
