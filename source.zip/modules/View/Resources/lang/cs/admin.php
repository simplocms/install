<?php

return [

    'grideditor_title' => 'Předdefinovaný obsah',

    'grid_editor_form' => [
        'no_views' => 'Pro tento modul nejsou k dispozici žádné šablony!',
        'label_view' => 'Šablona',
    ],

    'view_not_exist' => 'Šablona ":name" neexistuje!',

    'preview' => [
        'title' => 'Modul view',
        'not_found' => 'Šablona nenalezena!'
    ]

];
