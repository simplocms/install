<?php

return [

    'grideditor_title' => 'Predefined content',

    'grid_editor_form' => [
        'no_views' => 'No views are available for this module!',
        'label_view' => 'View',
    ],

    'view_not_exist' => 'View ":name" does not exist!',

    'preview' => [
        'title' => 'View module',
        'not_found' => 'View not found!'
    ],

];
