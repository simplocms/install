<?php

return [
    'name' => 'Image',
    'icon' => 'image',

    'grideditor_title' => 'module-image::admin.grideditor_title'
];
