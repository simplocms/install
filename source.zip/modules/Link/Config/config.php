<?php

return [
    'name' => 'Link',
    'icon' => 'link',

    'grideditor_title' => 'module-link::admin.grideditor_title'
];
