<strong>{{ trans('module-link::admin.preview.title') }}</strong><br>
{{ trans('module-link::admin.preview.text') }}: {{ $configuration->text }}
