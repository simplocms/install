<?php

return [
    'name' => 'Photogallery',
    'icon' => 'camera',

    'grideditor_title' => 'module-photogallery::admin.grideditor_title'
];
