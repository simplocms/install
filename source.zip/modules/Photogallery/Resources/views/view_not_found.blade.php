<div style="color: #a94442;background-color: #f2dede;padding: 15px;margin: 5px;border: 1px solid #ebccd1;">
    {!! trans('module-photogallery::admin.not_existing_view', ['name' => $view]) !!}
</div>
