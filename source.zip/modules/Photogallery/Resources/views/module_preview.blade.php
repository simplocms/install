<strong>{{ trans('module-photogallery::admin.grideditor_title') }}</strong><br>
{{ trans('module-photogallery::admin.grid_editor_form.labels.photogallery') }}: {{ $configuration->view }}
